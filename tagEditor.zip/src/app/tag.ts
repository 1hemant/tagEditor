export interface ITag {
    id: number;
    name: string;
}
