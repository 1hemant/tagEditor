import { Component, OnInit } from '@angular/core';
import { TagDataService } from '../tag-data.service';
import { ITag } from '../tag';
import { TagEditorService } from './tag-editor.service';


@Component({
  selector: 'app-tag-editor',
  templateUrl: './tag-editor.component.html',
  providers: [ TagEditorService ],
  styleUrls: ['./tag-editor.component.css']
})

export class TagEditorComponent implements OnInit {

  tags: ITag[];
  editTag: ITag;

  constructor(private tagDataService: TagDataService) { }

  ngOnInit() {
    this.getTagData();
  }

  getTagData(): void {
    this.tagDataService.getTagData()
      .subscribe(tags => this.tags = tags);
  }

  add(name: string): void {
    this.editTag = undefined;
    name = name.trim();
    if (!name) { return; }

    // The server will generate the id for this new tag
    const newTag: ITag = { name } as ITag;
    this.tagDataService.addTagData(newTag)
      .subscribe(tag => this.tags.push(tag));
  }

  delete(iTag: ITag): void {
    this.tags = this.tags.filter(h => h !== iTag);
    this.tagDataService.deleteTagData(iTag.id).subscribe();
  }

  edit(iTag) {
    this.editTag = iTag;
  }

  search(searchTerm: string) {
    this.editTag = undefined;
    if (searchTerm) {
      this.tagDataService.searchTagData(searchTerm)
        .subscribe(tags => this.tags = tags);
    }
  }

  update() {
    if (this.editTag) {
      this.tagDataService.updateTagData(this.editTag)
        .subscribe(tag => {
          const ix = tag ? this.tags.findIndex(t => t.id === tag.id) : -1;
          if (ix > -1) { this.tags[ix] = tag; }
        });
      this.editTag = undefined;
    }
  }
}
