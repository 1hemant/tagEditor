import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { ITag } from '../tag';
import { HttpErrorHandler, HandleError } from '../http-error-handler.service';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};

@Injectable({
  providedIn: 'root'
})
export class TagEditorService {
  _url = 'http://localhost:3000/tags';  // URL to web api
  private handleError: HandleError;
  constructor(
    private http: HttpClient,
    httpErrorHandler: HttpErrorHandler ) {
      this.handleError = httpErrorHandler.createHandleError('TagEditorService');
    }

  /** GET TagData from the server */
  getTagData (): Observable<ITag[]> {
    return this.http.get<ITag[]>(this._url)
      .pipe(
        catchError(this.handleError('getTagData', []))
      );
  }

  /* GET TagData whose name contains search term */
  searchTagData(term: string): Observable<ITag[]> {
    term = term.trim();

    // Add safe, URL encoded search parameter if there is a search term
    const options = term ?
     { params: new HttpParams().set('name', term) } : {};

    return this.http.get<ITag[]>(this._url, options)
      .pipe(
        catchError(this.handleError<ITag[]>('searchTagData', []))
      );
  }

  //////// Save methods //////////

  /** POST: add a new tag to the database */
  addTagData (iTag: ITag): Observable<ITag> {
    return this.http.post<ITag>(this._url, iTag, httpOptions)
      .pipe(
        catchError(this.handleError('addTagData', iTag))
      );
  }

  /** DELETE: delete the tag from the server */
  deleteTagData (id: number): Observable<{}> {
    const url = `${this._url}/${id}`; // DELETE api/TagData/42
    return this.http.delete(url, httpOptions)
      .pipe(
        catchError(this.handleError('deleteTagData'))
      );
  }

  /** PUT: update the tag on the server. Returns the updated tag upon success. */
  updateTagData (iTag: ITag): Observable<ITag> {
    httpOptions.headers =
      httpOptions.headers.set('Authorization', 'my-new-auth-token');

    return this.http.put<ITag>(this._url, iTag, httpOptions)
      .pipe(
        catchError(this.handleError('updateTagData', iTag))
      );
  }
}
