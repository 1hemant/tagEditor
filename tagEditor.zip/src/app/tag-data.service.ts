import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

import { ITag } from './tag';

import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpErrorHandler, HandleError } from './http-error-handler.service';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};

@Injectable({
  providedIn: 'root'
})
export class TagDataService {

  // private _url: string = "https://next.json-generator.com/api/json/get/EJ-V3KmPr";
  private _url = 'http://localhost:3000/tags';
  private handleError: HandleError;

  constructor( private http: HttpClient, httpErrorHandler: HttpErrorHandler) {
    this.handleError = httpErrorHandler.createHandleError('TabDataService');
  }

    getTagData(): Observable<ITag[]> {

      return this.http.get<ITag[]>(this._url)
      .pipe(
        catchError(this.handleError('getTabData', []))
      );
      // .catch(this.errorHandler);
    }

    /* GET tags whose name contains search term */
  searchTagData(term: string): Observable<ITag[]> {
    term = term.trim();

    // Add safe, URL encoded search parameter if there is a search term
    const options = term ?
     { params: new HttpParams().set('name', term) } : {};

    return this.http.get<ITag[]>(this._url, options)
      .pipe(
        catchError(this.handleError<ITag[]>('searchTagData', []))
      );
  }
        //////// Save methods //////////

  /** POST: add a new Tag to the database */
    addTagData(iTag: ITag): Observable<ITag> {
      return this.http.post<ITag>(this._url, iTag, httpOptions)
      .pipe(
        catchError(this.handleError('addTabData', iTag))
      );
    }

    /** DELETE: delete the Tag from the server */
  deleteTagData (id: number): Observable<{}> {
    const url = `${this._url}/${id}`;
    return this.http.delete(url, httpOptions)
      .pipe(
        catchError(this.handleError('deleteTagData'))
      );
  }

  /** PUT: update the Tag on the server. Returns the updated Tag upon success. */
  updateTagData (iTag: ITag): Observable<ITag> {
    httpOptions.headers =
      httpOptions.headers.set('Authorization', 'my-new-auth-token');

    return this.http.put<ITag>(this._url, iTag, httpOptions)
      .pipe(
        catchError(this.handleError('updateTagData', iTag))
      );
  }
}
