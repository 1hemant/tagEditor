import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { TagEditorComponent } from './tag-editor/tag-editor.component';
import { TagDataService } from './tag-data.service';
import { HttpClientModule } from '@angular/common/http';
import { TagEditorService } from './tag-editor/tag-editor.service';
import { MessageService } from './message.service';

@NgModule({
  declarations: [
    AppComponent,
    TagEditorComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [TagDataService, TagEditorService, MessageService],
  bootstrap: [AppComponent]
})
export class AppModule { }
